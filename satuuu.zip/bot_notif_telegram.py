
import requests

def send_telegram_message(token, chat_id, message):
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    payload = {
        "chat_id": chat_id,
        "text": message,
        "parse_mode": "Markdown"
    }
    response = requests.post(url, json=payload)
    return response.json()

# Example usage
if __name__ == "__main__":
    BOT_TOKEN = "your_bot_token_here"
    CHAT_ID = "your_chat_id_here"
    MESSAGE = "This is a test message from the bot."
    
    response = send_telegram_message(BOT_TOKEN, CHAT_ID, MESSAGE)
    print(response)
