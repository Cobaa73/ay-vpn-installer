#!/bin/bash

# Update system packages
echo "Updating system packages..."
sudo apt update && sudo apt upgrade -y

# Install Git, Python3, and pip
echo "Installing necessary packages..."
sudo apt install -y git python3 python3-pip

# Clone the repository
echo "Cloning the repository..."
git clone https://github.com/username/repository-name.git
cd repository-name

# Run the install script
echo "Running the install script..."
chmod +x install.sh
sudo ./install.sh

# Provide the Telegram bot script
cat <<EOF > bot_notif_telegram.py
import requests

def send_telegram_message(token, chat_id, message):
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    payload = {
        "chat_id": chat_id,
        "text": message,
        "parse_mode": "Markdown"
    }
    response = requests.post(url, json=payload)
    return response.json()

# Example usage
if __name__ == "__main__":
    BOT_TOKEN = "your_bot_token_here"
    CHAT_ID = "your_chat_id_here"
    MESSAGE = "This is a test message from the bot."

    response = send_telegram_message(BOT_TOKEN, CHAT_ID, MESSAGE)
    print(response)
EOF

# Prompt user to configure bot script
echo ""
echo "Installation complete! Please configure the bot script before running:"
echo "1. Open 'bot_notif_telegram.py' and replace 'your_bot_token_here' with your bot token."
echo "2. Replace 'your_chat_id_here' with your Telegram chat ID."
echo "To run the bot: python3 bot_notif_telegram.py"
