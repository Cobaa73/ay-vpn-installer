<!DOCTYPE html>
<h2 align="center">
  SIMPLE XRAY Multiport Websocket Free<br>

<p align="center">  
  <img src="https://readme-typing-svg.herokuapp.com?color=%2336BCF7&center=true&vCenter=true&lines=Rerechan02" />  
  </p>

![Rerechan02 card name](https://cardivo.vercel.app/api?name=Funny%20Store&description=Hi,%20everyone!%20and%20Nice%20to%20meet%20you%20%F0%9F%91%8B&image=https://raw.githubusercontent.com/Rerechan02/simple-xray/main/funny1.jpg?v=4&backgroundColor=%23ecf0f1&telegram=/&github=Rerechan02&pattern=leaf&colorPattern=%23eaeaea)
  
## ⚠️ PLEASE README ⚠️
<b>
<br>
PLEASE MAKE SURE YOUR DOMAIN SETTINGS IN YOUR CLOUDFLARE AS BELOW (SSL/TLS SETTINGS)<br>
<br><br>1. Your SSL/TLS encryption mode is Full<br>2. Enable SSL/TLS Recommender ✅<br>3. Edge Certificates > Disable Always Use HTTPS (off)
<br>
</b>
</b>

## For Debian 9 & 10 Only For First Time Installation (Update Repo) <br>
 
  ```html
 apt update -y && apt upgrade -y && apt dist-upgrade -y && reboot
  ```
##   For Ubuntu 18.04 & 20.04 Only For First Time Installation (Update Repo) <br>
  
  ```html
 apt-get update && apt-get upgrade -y && apt dist-upgrade -y && update-grub && apt install curl -y && reboot
 ```
## Installation Link<br>

  ```html
wget https://raw.githubusercontent.com/Rerechan02/XRAY/main/setup.sh && chmod +x setup.sh && ./setup.sh
  ```
<b>
<br>
##TYPE funny To Menu All Service
<br>
<br>
## SIMPLE XRAY MULTIPORT WEBSOCKET AUTOSCRIPT DETAILS
<b>
[ XRAY SERVICES ] <br>
<br>
✅ XRAY VMESS WEBSOCKET TLS & NON-TLS 443/80<br>
✅ XRAY VLESS WEBSOCKET TLS & NON-TLS 443/80 (SUPPORT CUSTOM PATH / WORRYFREE)<br>
✅ XRAY TROJAN WEBSOCKET TLS & NON-TLS 443/80<br>
<br>
[ OTHER SERVICES ] <br>
<br>
✅ BANDWITH MONITOR <br>
✅ YAML LINK <br>
✅ CHECK LOGIN USER <br>
<br>

<a href="https://t.me/fn_project" target=”_blank”><img src="https://img.shields.io/static/v1?style=for-the-badge&logo=Telegram&label=Telegram&message=Click%20Here&color=blue"></a><br>

![image](https://raw.githubusercontent.com/Rerechan02/simple-xray/main/funny2.png)<br></html>