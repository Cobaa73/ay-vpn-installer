
#!/bin/bash

# Update and install dependencies
echo "Updating system and installing dependencies..."
sudo apt update && sudo apt install -y python3 python3-pip

# Install Python requirements
echo "Installing required Python packages..."
pip3 install requests

# Notify user
echo "Sending completion notification..."
python3 notify.py

echo "Installation completed successfully!"
