#!/bin/bash

# Ensure the system is up-to-date
echo "Updating system packages..."
sudo apt update && sudo apt upgrade -y

# Install Python3 and pip if not already installed
echo "Installing Python3 and pip..."
sudo apt install -y python3 python3-pip

# Install the required Python library
echo "Installing required Python libraries..."
pip3 install requests

# Provide information about the bot script
echo ""
echo "Installation complete!"
echo "To configure and run the bot, follow these steps:"
echo "1. Open the 'bot_notif_telegram.py' file in a text editor."
echo "2. Replace 'your_bot_token_here' with your Telegram bot token."
echo "3. Replace 'your_chat_id_here' with the chat ID of the recipient."
echo "4. Run the script using: python3 bot_notif_telegram.py"
