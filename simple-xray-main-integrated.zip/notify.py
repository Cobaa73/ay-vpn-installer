
import requests

def send_notification(message, bot_token, chat_id):
    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    payload = {
        "chat_id": chat_id,
        "text": message
    }
    response = requests.post(url, json=payload)
    return response.status_code, response.json()

if __name__ == "__main__":
    # Example values for bot_token and chat_id, replace with your actual details
    bot_token = "your_telegram_bot_token"
    chat_id = "your_chat_id"
    message = "Task completed successfully!"

    status, response = send_notification(message, bot_token, chat_id)
    print(f"Notification sent: {status}, Response: {response}")
